package hxcodec;

import openfl.display.Sprite;
import openfl.media.Video;

class VideoSprite extends Sprite {
    public var video:Video;

    public function new() {
        super();
        video = new Video();
        addChild(video);
    }

    public function play(path:String):Void {
        trace("Play video: " + path);
    }

    public function stop():Void {
        trace("Stop video");
    }

    public function dispose():Void {
        trace("Dispose video");
    }
}